define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SwitchValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $fragment, $application } = context;

      if ($fragment.variables.switchModeVar === true) {
        const callFunctionResult = await $application.functions.setDark();
      } else {
        const callFunctionResult = await $application.functions.setLight();
      }
    }
  }

  return SwitchValueChangeChain;
});
