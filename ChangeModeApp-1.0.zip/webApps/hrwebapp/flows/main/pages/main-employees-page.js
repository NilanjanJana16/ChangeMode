define([], () => {
  'use strict';

  class PageModule {
  }

  PageModule.prototype.print = function(){
    console.log(">>>>>>>>>. SPOUG >>>>>>>>>>>");
  };

  
  return PageModule;
});
