define([], () => {
  'use strict';

  class AppModule {
  }

  document.body.style="background-color: var(--bs-main-color-primary);transition: 0.5s;";
  let theme = "light";
  const root = document.querySelector(":root");

  AppModule.prototype.setLight = function(){
    root.style.setProperty(
      "--bs-main-color-primary",
      "linear-gradient(318.32deg, #c3d1e4 0%, #dde7f3 55%, #d4e0ed 100%)"
    );
    root.style.setProperty("--bs-main-color-light","#312d2a");
    root.style.setProperty("--bs-btns", "unset");
  };

  AppModule.prototype.setDark = function(){
    root.style.setProperty("--bs-main-color-primary", "#312d2a");
    root.style.setProperty("--bs-main-color-light", "#fff");
    root.style.setProperty("--bs-btns", "#fff");
  };

AppModule.prototype.setTheme = function(){
    switch (theme) {
      case "dark":
        AppModule.prototype.setLight();
        theme = "light";
        break;
      case "light":
        AppModule.prototype.setDark();
        theme = "dark";
        break;
    }
    };
    
  return AppModule;
});
